
1/ Required Settings Changes

For a better experience, follow "1 - Required Settings Changes" instructions.


2/ FPS lost

If you notice significant FPS drop, check "2 - Optional Changes" for help, or try the lower quality versions of ABF Shader :
> ABF HHQ : Very High Quality
> ABF HQ : High Quality (recommanded for most computer)
> ABF LQ : Low Quality
> ABF LLQ : Very Low Quality